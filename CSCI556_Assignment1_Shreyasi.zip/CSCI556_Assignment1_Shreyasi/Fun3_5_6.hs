module Fun3_5_6
(mult, div23n5, addTax, subTax)
where


mult :: Int -> Int -> Int
mult  n1 n2 = if n1==0 then
                         0
                      else if n2==0 then
                          0
                       else
                           n1 + mult n1 (n2-1)
	
	
div23n5 :: Int -> Bool
div23n5 n = if ( ( ((n `mod` 2) ==0) || ((n `mod` 3)==0) ) && ((n `mod` 5) /= 0) ) then
                             True
                    else
                              False
							  
addTax :: Double -> Double -> Double
addTax c p = c+((c*p)/100)            

subTax :: Double -> Double -> Double 
subTax c p  =  c/(1+(p/100))
