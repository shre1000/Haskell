CSci 556: Multiparadigm Programming
Assignments #1, Spring 2017

Name: Shreyasi Ramesh Kokamthankar
Student Id: 10599411

CSCI556_Assignment1_Shreyasi.zip contains:

Fun_3_5_6.hs : question 3 5 6 from assignment
Test_Fun_3_5_6.hs : Test Function for Fun_3_5_6.hs

Fun_7_module_point.hs : point module from question 7 
Fun_7_module_segment.hs : segment module from question 7 
Test_Fun_7.hs : Test function for question 7